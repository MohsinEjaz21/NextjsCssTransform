import { useEffect, useState } from "react";
import { DefaultCssTemplate } from '../../inputcss';
var extractor = require('css-color-extractor');

function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
}

function replaceAll(str, find, replace) {
  return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

function countMatch(str, find) {
  return str.match(new RegExp(escapeRegExp(find), 'g'));
}

function sortColorBasedOnCount(a, b) {
  var countA = a.count;
  let countB = b.count;
  if (countA < countB) return 1;
  if (countA > countB) return -1;
  return 0;
}

export default function CssTransform() {
  const [inputCss, setInputCss] = useState(DefaultCssTemplate);
  const [outputCss, setOutputCss] = useState('');
  const [colorArr, setColorArr] = useState([]);

  function handleTransform() {
    let tempCss = inputCss;
    let tempColorsArr: any = [];
    var options = {
      withoutGrey: false, // set to true to remove rules that only have grey colors
      withoutMonochrome: false, // set to true to remove rules that only have grey, black, or white colors
      colorFormat: 'hexString' // transform colors to one of the following formats: hexString, rgbString, percentString, hslString, hwbString, or keyword
    };
    let tempColors = extractor.fromCss(tempCss).filter((colorVal: any) => colorVal !== '0');

    console.log("tempColors", tempColors);


    tempColors.forEach((colorVal: any, index: number) => {
      let color = colorVal.replace(/\s/g, '');
      let currCssVar = `--color__${index + 1}`;
      let colorName = `var(${currCssVar})`;
      let matchColorLen = (countMatch(tempCss, color) || []).length
      let tempColorObj = {}
      tempColorObj['key'] = currCssVar;
      tempColorObj['value'] = colorVal;
      tempColorObj['count'] = matchColorLen;
      tempColorsArr.push(tempColorObj);
      tempCss = replaceAll(tempCss, color, colorName);
    });

    console.log(" NEW CSS ")
    console.log(tempCss)

    tempColorsArr.sort(sortColorBasedOnCount);
    setOutputCss(tempCss);
    setColorArr(tempColorsArr);
  }

  useEffect(() => {
    handleTransform()
    return () => { }
  }, [])



  return (
    <>

      {/* Text box for input css */}

      <div className="split left">
        <div className="heading-primary">
          Enter Yours CSS 👇
        </div>
        <textarea
          className="inputcss-textarea"
          value={inputCss}
          onChange={(e) => setInputCss(e.target.value)}
        />
      </div>
      <div className="split right">
        <div className="heading-primary">
          Dynamic CSS with varibles 🌸

          {/* handleTransform on click */}
          <button className="btn btn-primary" onClick={handleTransform}>
            Transform
          </button>

        </div>


        <pre className="generated-css">
          :root &#123;
          {colorArr.map((color: any, index) => {
            return (
              <div key={index}>
                {color.key} : {color.value};         /* {color.count} */
              </div>
            )
          })}
          &#125;
          <br />
          {JSON.parse(JSON.stringify(outputCss, null, 2))}
        </pre>


      </div>



    </>
  )
}


// let colorsStringify = JSON.stringify(tempColorObj, null, 2)
// const tempFormatedColors = colorsStringify.replace(/"([^"]+)":/g, '$1:').split(',').join(';');

{/* {colors.map((color, index) => {
        return (
          <div key={index}>
            <div style={{ backgroundColor: color }}>
              {index} ----  {color}
            </div>
          </div>
        )
      })} */}