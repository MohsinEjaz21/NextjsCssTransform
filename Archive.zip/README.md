use this link for demo https://nextjs-dynamic-css.vercel.app/CssUtility/

[]: # Language: markdown
[]: # Path: README.md